dd_pat: "$DD_PAT"
# provide a metric_prefix value that should be used send to DD
metric_prefix: ""
# provide the network name (testnet, canary, mainnet, etc)
network: ""
# seconds to wait between each execution
interval_poll: 15
endpoints:
  - url: "http://127.0.0.1:3030/{network}/peers/count"
    metric_name: "nodes"
  - url: "http://127.0.0.1:3030/{network}/block/height/latest"
    metric_name: "block_height"
  - url: "http://127.0.0.1:3030/{network}/block/latest"
    metric_name: "coinbase_target"
    path: "header.metadata.coinbase_target"
  - url: "http://127.0.0.1:3030/{network}/committee/latest"
    metric_name: "committee.starting_round"
    path: "starting_round"
  - url: "http://127.0.0.1:3030/{network}/committee/latest"
    metric_name: "committee.total_stake"
    path: "total_stake"
  - url: "http://127.0.0.1:3030/{network}/committee/latest"
    metric_name: "committee.members.length"
    path: "members"
    op: "count"
  # comment the lines below when running 
  # apimon on a node without --metrics enabled
  - url: "http://127.0.0.1:9000"
    metric_name: "prometheus"